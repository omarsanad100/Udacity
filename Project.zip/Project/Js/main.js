// create header elements

let headerNav = document.querySelector("header nav");
let navUl = document.querySelector("header nav ul");
let mobileUl = document.querySelector("header nav .mobile ul");
let sec = document.querySelectorAll("section");
console.log(sec)
for (let i = 0; i < sec.length; i++) {
    let li = document.createElement("li");
    li.innerText = sec[i].classList;
    navUl.appendChild(li);
}

// create mobile menu nav
for (let i = 0; i < sec.length; i++) {
    let li = document.createElement("li");
    li.innerText = sec[i].classList;
    mobileUl.appendChild(li);
}


// create menu icon
let menuele = document.createElement("i");
menuele.classList = "fa-solid fa-bars";
menuele.id = "menu";
headerNav.appendChild(menuele)



// Dispaly and hide mobile menu
let menu = document.getElementById("menu")
let mobileNav = document.querySelector(".mobile")
menu.addEventListener("click", () => {
    mobileNav.classList.toggle("active")
})

// Scroll to
let lis = document.querySelectorAll("header li")

lis.forEach(li => {
    li.addEventListener("click", () => {
        if (li.innerHTML === "home") {
            scrollTo({
                top: home.y,
                left: 0,
                behavior: "smooth"
            })
        } else if (li.innerHTML === "about") {
            scrollTo({
                top: about.y,
                left: 0,
                behavior: "smooth"
            })
        } else if (li.innerHTML === "projects") {
            scrollTo({
                top: projects.y,
                left: 0,
                behavior: "smooth"
            })
        } else if (li.innerHTML === "contact") {
            scrollTo({
                top: contact.y,
                left: 0,
                behavior: "smooth"
            })
        }
    })
})


let home = sec[0].getBoundingClientRect();
let about = sec[1].getBoundingClientRect();
let projects = sec[2].getBoundingClientRect();
let contact = sec[3].getBoundingClientRect();

// change background
document.addEventListener("scroll", () => {
    if (scrollY >= (home.y - 150) && scrollY < (about.y - 150)) {
        sec[0].classList.add("active")
    } else {
        sec[0].classList.remove("active")
    }


    if (scrollY >= (about.y - 150) && scrollY < (projects.y - 150)) {
        sec[1].classList.add("active")
    } else {
        sec[1].classList.remove("active")
    }

    
    if (scrollY >= (projects.y - 150) && scrollY < (contact.y - 150)) {
        sec[2].classList.add("active")
    } else {
        sec[2].classList.remove("active")
    }

    
    if (scrollY >= (contact.y- 150)) {
        sec[3].classList.add("active")
    } else {
        sec[3].classList.remove("active")
    }
})